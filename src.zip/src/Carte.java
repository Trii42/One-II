
public class Carte {

    public int longueur;
    public int largeur;

    public Carte(final int longueur, final int largeur) {
        super();
        this.longueur = longueur;
        this.largeur = largeur;
    }

    public int getLongueur() {
        return longueur;
    }

    public void setLongueur(final int longueur) {
        this.longueur = longueur;
    }

    public int getLargeur() {
        return largeur;
    }

    public void setLargeur(final int largeur) {
        this.largeur = largeur;
    }

}
